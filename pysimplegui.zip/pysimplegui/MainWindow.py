import PySimpleGUI as sg
from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk
import ctypes
def show():
    print("学習機能")
def show1():
    print("世代管理")
def show2():
    print("アプリ情報")

layout_column_button=[[sg.Button("学習機能", key = show, button_color= "blue", image_filename="./button.png",
         border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,0))],
         [sg.Button("世代管理", key = show1, button_color= "blue",image_filename="./button.png",
         border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,15))]]
root = Tk()
img = Image.open("./tem1.png")
photoImg =  ImageTk.PhotoImage(img)
layout_column_logo = [[sg.Image(key='tem')]]
#
#layouttrain = [[sg.Image(filename='./tem.png', key='tem1')]]
#
layout_train = [[sg.Text('ギット情報', key = "train", justification='r',
 background_color="#E0EFF9", text_color="black", font=("Helvetica", 13, "bold"),
    border_width = 0)]]  

layout = [[sg.Column(layout_train, key = "Learning", visible = False, background_color="#E0EFF9", expand_x= True, expand_y = True), sg.Column(layout_column_logo, key = "logo", background_color="#E0EFF9", expand_x= True, expand_y= True), 
sg.Column(layout_column_button,key = "button", background_color="#E0EFF9", expand_x= True, expand_y= True, pad=(30,90))], 
[sg.Button("アプリ情報", key = show2, button_color= ("black","#87C0FF"),font=("Helvetica", 10), pad = ((725,0),(0,0)))]]

window = sg.Window("AI学習プラットフォーム",layout,background_color="#E0EFF9", border_depth = 0,size =(838,490)).Finalize()
window["tem"].update(data = photoImg)

while True:
    event, values = window.read()
    if callable(event):
        
        window["logo"].update(visible = False)     
        window["button"].update(visible = False)
        window[show2].update(visible = False)
        window["Learning"].update(visible = True)
    elif event in (sg.WIN_CLOSED, "Exit"):
        break
window.close()
root.mainloop()