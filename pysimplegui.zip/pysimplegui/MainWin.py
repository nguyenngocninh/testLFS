import PySimpleGUI as sg
from tkinter import * 
import tkinter as tk
from tkinter.ttk import *
from PIL import Image
from PIL import ImageTk

git_repo = "server@10.116.45.16:~/git/project.git/"
git_branch   = "master"
i= 0

def manage_function(window):
    window["main_layout"].update(visible = False)
    window["manage_layout"].update(visible = True)

def app_infor(window):
    app_infor_header = sg.Text("アプリ情報", background_color="#E0EFF9",text_color="black", font=("Helvetica", 13, "bold"),border_width = 0)
    app_infor_content = sg.Text(text = "", key = "software_infor", size = (30,4), background_color = "white",text_color="black", font=("Helvetica", 13),border_width = 3)
    app_quit_infor = sg.Button("OK", key = "Exit")
    layout2 = [[app_infor_header],[app_infor_content],[app_quit_infor]]
    window2 = sg.Window("",layout2, size =(350,200), background_color="#E0EFF9",element_justification = "center").Finalize()
    while True:
        event, value = window2.read()
        if event in (sg.WINDOW_CLOSED, "Exit"):
            break
    window2.close()
def get_git_infor(git_repo, git_branch):
    git_infor_update = "Git repository = " + git_repo + "\n" + "Git branch = " + git_branch
    return git_infor_update

def update_progress_bar(window, value, max_value):
    window["train_progressbar"].update(value,max_value)

def learning_function(window):
    window["main_layout"].update(visible = False)
    window["train_layout"].update(visible = True)
    window["model_result_infors_fail"].update(visible = False)
    window["model_result_infors_success"].update(visible = False)

    window["git_information"].update(get_git_infor(git_repo, git_branch))

def back_to_main(window):
    window["main_layout"].update(visible = True)
    window["train_layout"].update(visible = False)

def back_to_main1(window):
    window["model_result_infors_success"].update(visible = False)
    window["main_layout"].update(visible = True)

def back_to_main2(window):
    window["model_result_infors_fail"].update(visible = False)
    window["main_layout"].update(visible = True)

def train_model(window):
    global i 
    i= 0
    window["train_progress_layout"].update(visible = True)
    window["train_progressbar"].update(0,100)
    window["train_layout"].update(visible = False)
    
def train_model_result(window, result, result_log):
    window["train_progress_layout"].update(visible = False)

    if result == "success":
        window["train_progressbar_result_success"].update(10,10)
        window["model_train_result_infor_success"].update("Model is trained sucessfully")
        window["train_log_success"].update(result_log)
        window["model_result_infors_success"].update(visible = True)
    else :
        window["model_train_result_infor_fail"].update("Model is trained failed")
        window["train_progressbar_result_fail"].update(5,10)
        window["train_log_fail"].update(result_log)
        window["model_result_infors_success"].update(visible = False)
        window["model_result_infors_fail"].update(visible = True)

root = Tk()
img = Image.open("./tem1.png")
photoImg =  ImageTk.PhotoImage(img)

layout_logo = sg.Image(key='tem')
learing_function_button = sg.Button("学習機能", key = learning_function, button_color= "#E0EFF9", image_filename="./button.png",
                        border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,0))
management_button = sg.Button("世代管理", key = manage_function, button_color= "#E0EFF9",image_filename="./button.png",
                        border_width = 0, font=("Helvetica", 16, "bold"), pad = (0,15))

main_window_button=[[learing_function_button],[management_button]]
img = Image.open("./tem1.png")
photoImg =  ImageTk.PhotoImage(img)
layout_column_logo = [[sg.Image(key='tem')]]

main_layout = [[sg.Column(layout_column_logo, key = "logo", background_color="#E0EFF9"),
sg.Column(main_window_button,key = "button", background_color="#E0EFF9")],
[sg.Button("アプリ情報", key = app_infor,button_color= ("black","#87C0FF"),font=("Helvetica", 10), pad = ((725,0),(0,0)))]]


git_infor_header = sg.Text("Git information", pad = (5,40), size = (16,1),  background_color="#E0EFF9",text_color="black", font=("Helvetica", 13, "bold"),border_width = 0)
git_infor_content = sg.Text(text = "", key = "git_information", size = (48,3), background_color = "white",text_color="black", font=("Helvetica", 13),border_width = 3)
switch_branch_button = sg.Button("Change", key = "change")

git_information_train = [git_infor_header, git_infor_content, switch_branch_button]

network_config_header = [sg.Text("Configuration", pad = (5,10), background_color="#E0EFF9", size = (16,1), text_color="black", font=("Helvetica", 13, "bold"),border_width = 0)]

architecture_header = sg.Text("Architecture", pad = (5,20),background_color="#E0EFF9", size = (16,1), text_color="black", font=("Helvetica", 13),border_width = 0)
architecture_content = sg.Combo(['MaskRCNN'], enable_events=True,key='combo', size = (48,1), background_color = "white",text_color="black", font=("Helvetica", 13))
architecture = [architecture_header, architecture_content]


datset_train_header = sg.Text("Input dataset", pad = (5,20), background_color="#E0EFF9", size = (16,1), text_color="black", font=("Helvetica", 13),border_width = 0)
dataset_train_content = sg.Input("", key = "datset_train",size = (48,1), background_color = "white",text_color="black", font=("Helvetica", 13),border_width = 3)
browse_dataset_button = sg.FolderBrowse(button_text="Browse", target="datset_train")
dataset_train = [datset_train_header, dataset_train_content, browse_dataset_button]

model_train_header = sg.Text("Output model", pad = (5,20), background_color="#E0EFF9", size = (16,1), text_color="black", font=("Helvetica", 13),border_width = 0)
model_train_content = sg.Input("", key = "model_train",size = (48,1), background_color = "white",text_color="black", font=("Helvetica", 13),border_width = 3)
browse_model_button = sg.FileSaveAs(button_text="Browse", target="model_train")
model_train = [model_train_header, model_train_content, browse_model_button]

epochs_train_header = sg.Text("Epocks", pad = (5,20), background_color="#E0EFF9", size = (16,1), text_color="black", font=("Helvetica", 13),border_width = 0)
epochs_train_content = sg.Input("", key = "epochs",size = (48,1), background_color = "white",text_color="black", font=("Helvetica", 13),border_width = 3)
epochs_train = [epochs_train_header, epochs_train_content]

train_mainback_button = sg.Button("Back", pad = (5,20),key = back_to_main)
blank_text = sg.Text("", pad = (5,20), background_color="#E0EFF9", size = (66,1), text_color="black", font=("Helvetica", 13),border_width = 0)
train_button = sg.Button("Train", pad = (5,20),key = train_model)


train_layout = [git_information_train, network_config_header,architecture, dataset_train,model_train,epochs_train, [train_mainback_button, blank_text, train_button]]

model_train_progress_infor = sg.Text("Model is being trained" ,pad = (0, 15),background_color="#E0EFF9", text_color="black", font=("Helvetica", 18, "bold"),border_width = 0)
train_progressbar =  sg.ProgressBar(100, orientation='h',size=(40,40), key='train_progressbar', bar_color = ("green", "white"))

train_progress_layout = [[model_train_progress_infor],[train_progressbar]]

model_train_result_infor_success = sg.Text("", key = "model_train_result_infor_success",justification= "center",size= (50,1), pad = (0, 15),background_color="#E0EFF9", text_color="black", font=("Helvetica", 14, "bold"),border_width = 0)
train_progressbar_result_success =  sg.ProgressBar(100, orientation='h',size=(30,30), key='train_progressbar_result_success', bar_color = ("green", "white"))
train_log_success = sg.MLine(default_text= "< detail:",key="train_log_success", size=(100,15),pad=(100,20))
train_result_ok_button_success = sg.Button("OK", pad = (5,10),key = back_to_main1)
train_result_ok_button_fail = sg.Button("OK", pad = (5,10),key = back_to_main2)

model_train_result_infor_fail = sg.Text("", key = "model_train_result_infor_fail",justification= "center",size= (50,1), pad = (0, 15),background_color="#E0EFF9", text_color="black", font=("Helvetica", 14, "bold"),border_width = 0)
train_progressbar_result_fail =  sg.ProgressBar(100, orientation='h',size=(30,30), key='train_progressbar_result_fail', bar_color = ("red", "white"))
train_log_fail = sg.MLine(default_text= "< detail:",key="train_log_fail", size=(100,15),pad=(100,20))

model_result_infors_success = [[model_train_result_infor_success],[train_progressbar_result_success],[train_log_success],[train_result_ok_button_success]]
model_result_infors_fail = [[model_train_result_infor_fail],[train_progressbar_result_fail],[train_log_fail],[train_result_ok_button_fail]]


menu_def = [['クローン',['クローン']],  ['チェックアウト',['チェックアウト']],  
            ['プッシュ', ['データセット', 'モデル'],],      
            ['プル', ['プル' ] ],
            ["データセット作成", ["データセット作成"]]]

menubar = sg.Menu(menu_def,  font=("Helvetica", 10, "bold"))

manage_layout = [[menubar]]

manage_layout_column = sg.Column(manage_layout, key = "manage_layout", background_color="#E0EFF9", visible=False)
main_layout_column = sg.Column(main_layout,key = "main_layout",background_color="#E0EFF9")
train_layout_column = sg.Column(train_layout, key = "train_layout", visible=False, background_color="#E0EFF9", expand_x= True, expand_y = True)
train_progress_layout_column = sg.Column(train_progress_layout,key = "train_progress_layout", element_justification="center",pad = (200,150), background_color="#E0EFF9", visible=False)
model_result_infors_success_column = sg.Column(model_result_infors_success,key = "model_result_infors_success", element_justification="center",pad = (50,20), background_color="#E0EFF9", visible=False)
model_result_infors_fail_column = sg.Column(model_result_infors_fail,key = "model_result_infors_fail", element_justification="center",pad = (50,20), background_color="#E0EFF9", visible=False)

management_layout = [[main_layout_column, train_progress_layout_column,train_layout_column, model_result_infors_success_column, model_result_infors_fail_column, manage_layout_column]]
window = sg.Window("AI learning platform",management_layout,background_color="#E0EFF9", border_depth = 0,size =(838,490)).Finalize()
window["tem"].update(data = photoImg)

while True:
    event, value = window.read(1000)
    print (str(event))
    i= i+20
    print(i)
    if (i <= 100):
        update_progress_bar(window,i, 100)
    elif (i == 120):
        train_model_result(window,"success", "trainok")

    elif (i == 160):
        train_model_result(window,"fail", "trainfail")

    if callable(event):
        event(window)
        #if event == "Learning Function":
            #learning_function(window)
    elif event in (sg.WINDOW_CLOSED, "Exit"):
        break
window.close()